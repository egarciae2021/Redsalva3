<div class="shortcode-html">
	<section class="g-brd-top g-brd-bottom g-brd-gray-light-v4 g-py-20">
		<div class="container">
			<div class="d-sm-flex text-center">
				<div class="align-self-center">
					<h2 class="h3 g-font-weight-300 w-100 g-mb-10 g-mb-0--md">Servicios</h2>
				</div>

				<div class="align-self-center ml-auto">
					<ul class="u-list-inline">
						<li class="list-inline-item g-mr-5">
							<a class="u-link-v5 g-color-main" href="/">Inicio</a>
							<i class="g-color-gray-light-v2 g-ml-5">/</i>
						</li>
						<li class="list-inline-item g-color-primary">
							<span>Servicios</span>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</section>
</div>
<section class="container g-pt-50 g-pb-40">
	<div class="row">
		<div class="col-lg-12">
			<div class="row">
				<div class="col-lg-3 g-mb-30">
					<div class="text-center u-block-hover">
						<a href="/servicios/anestesiologia">
							<img class="img-fluid u-shadow-v2" src="/img/anestesiologia.jpg" width="100%" alt="Anestesiología | Servicios | Clínica Montesur" title="Anestesiología | Servicios | Clínica Montesur">
						</a>
						<h3 class="h6 g-color-black g-font-weight-600 g-font-size-15 text-uppercase g-mt-10">
							<a class="u-link-v5 g-color-black g-color-primary--hover" href="/servicios/anestesiologia">Anestesiología</a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 g-mb-30">
					<div class="text-center u-block-hover">
						<a href="/servicios/centro-obstetrico">
							<img class="img-fluid u-shadow-v2" src="/img/centro-obstetrico.jpg" width="100%" alt="Centro obstétrico | Servicios | Clínica Montesur" title="Centro obstétrico | Servicios | Clínica Montesur">
						</a>
						<h3 class="h6 g-color-black g-font-weight-600 g-font-size-15 text-uppercase g-mt-10">
							<a class="u-link-v5 g-color-black g-color-primary--hover" href="/servicios/centro-obstetrico">Centro obstétrico</a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 g-mb-30">
					<div class="text-center u-block-hover">
						<a href="/servicios/centro-quirurgico">
							<img class="img-fluid u-shadow-v2" src="/img/centro-quirurgico.jpg" width="100%" alt="Centro quirúrgico | Servicios | Clínica Montesur" title="Centro quirúrgico | Servicios | Clínica Montesur">
						</a>
						<h3 class="h6 g-color-black g-font-weight-600 g-font-size-15 text-uppercase g-mt-10">
							<a class="u-link-v5 g-color-black g-color-primary--hover" href="/servicios/centro-quirurgico">Centro quirúrgico</a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 g-mb-30">
					<div class="text-center u-block-hover">
						<a href="/servicios/consultas-externas">
							<img class="img-fluid u-shadow-v2" src="/img/consultas-externas.jpg" width="100%" alt="Consultas externas | Servicios | Clínica Montesur" title="Consultas externas | Servicios | Clínica Montesur">
						</a>
						<h3 class="h6 g-color-black g-font-weight-600 g-font-size-15 text-uppercase g-mt-10">
							<a class="u-link-v5 g-color-black g-color-primary--hover" href="/servicios/consultas-externas">Consultas externas</a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 g-mb-30">
					<div class="text-center u-block-hover">
						<a href="/servicios/emergencia">
							<img class="img-fluid u-shadow-v2" src="/img/emergencia.jpg" width="100%" alt="Emergencia | Servicios | Clínica Montesur" title="Emergencia | Servicios | Clínica Montesur">
						</a>
						<h3 class="h6 g-color-black g-font-weight-600 g-font-size-15 text-uppercase g-mt-10">
							<a class="u-link-v5 g-color-black g-color-primary--hover" href="/servicios/emergencia">Emergencia</a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 g-mb-30">
					<div class="text-center u-block-hover">
						<a href="/servicios/farmacia">
							<img class="img-fluid u-shadow-v2" src="/img/farmacia.jpg" width="100%" alt="Farmacia | Servicios | Clínica Montesur" title="Farmacia | Servicios | Clínica Montesur">
						</a>
						<h3 class="h6 g-color-black g-font-weight-600 g-font-size-15 text-uppercase g-mt-10">
							<a class="u-link-v5 g-color-black g-color-primary--hover" href="/servicios/farmacia">Farmacia</a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 g-mb-30">
					<div class="text-center u-block-hover">
						<a href="/servicios/hospitalizacion">
							<img class="img-fluid u-shadow-v2" src="/img/hospitalizacion.jpg" width="100%" alt="Hospitalización | Servicios | Clínica Montesur" title="Hospitalización | Servicios | Clínica Montesur">
						</a>
						<h3 class="h6 g-color-black g-font-weight-600 g-font-size-15 text-uppercase g-mt-10">
							<a class="u-link-v5 g-color-black g-color-primary--hover" href="/servicios/hospitalizacion">Hospitalización</a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 g-mb-30">
					<div class="text-center u-block-hover">
						<a href="/servicios/laboratorio-clinico">
							<img class="img-fluid u-shadow-v2" src="/img/laboratorio.jpg" width="100%" alt="Laboratorio | Servicios | Clínica Montesur" title="Laboratorio | Servicios | Clínica Montesur">
						</a>
						<h3 class="h6 g-color-black g-font-weight-600 g-font-size-15 text-uppercase g-mt-10">
							<a class="u-link-v5 g-color-black g-color-primary--hover" href="/servicios/laboratorio-clinico">Laboratorio clínico</a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 g-mb-30">
					<div class="text-center u-block-hover">
						<a href="/servicios/laboratorio-patologico">
							<img class="img-fluid u-shadow-v2" src="/img/patologia.jpg" width="100%" alt="Patología | Servicios | Clínica Montesur" title="Patología | Servicios | Clínica Montesur">
						</a>
						<h3 class="h6 g-color-black g-font-weight-600 g-font-size-15 text-uppercase g-mt-10">
							<a class="u-link-v5 g-color-black g-color-primary--hover" href="/servicios/laboratorio-patologico">Laboratorio Patológico</a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 g-mb-30">
					<div class="text-center u-block-hover">
						<a href="/servicios/neonatologia-servicio">
							<img class="img-fluid u-shadow-v2" src="/img/neonatologia-servicio.jpg" width="100%" alt="Neonatología | Servicios | Clínica Montesur" title="Neonatología | Servicios | Clínica Montesur">
						</a>
						<h3 class="h6 g-color-black g-font-weight-600 g-font-size-15 text-uppercase g-mt-10">
							<a class="u-link-v5 g-color-black g-color-primary--hover" href="/servicios/neonatologia-servicio">Neonatología</a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 g-mb-30">
					<div class="text-center u-block-hover">
						<a href="/servicios/tamizaje-neonatal">
							<img class="img-fluid u-shadow-v2" src="/img/tamizaje.jpg" width="100%" alt="Neonatología | Servicios | Clínica Montesur" title="Neonatología | Servicios | Clínica Montesur">
						</a>
						<h3 class="h6 g-color-black g-font-weight-600 g-font-size-15 text-uppercase g-mt-10">
							<a class="u-link-v5 g-color-black g-color-primary--hover" href="/servicios/tamizaje-neonatal">Tamizaje neonatal</a>
						</h3>
					</div>
				</div>
				<div class="col-lg-3 g-mb-30">
					<div class="text-center u-block-hover">
						<a href="/servicios/visita-guiada">
							<img class="img-fluid u-shadow-v2" src="/img/visita-guiada.jpg" width="100%" alt="Visita guiada | Servicios | Clínica Montesur" title="Visita guiada | Servicios | Clínica Montesur">
						</a>
						<h3 class="h6 g-color-black g-font-weight-600 g-font-size-15 text-uppercase g-mt-10">
							<a class="u-link-v5 g-color-black g-color-primary--hover" href="/servicios/visita-guiada">Visita guiada</a>
						</h3>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php require_once('contact.php'); ?>