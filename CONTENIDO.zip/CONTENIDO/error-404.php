<div class="shortcode-html">
	<section class="g-brd-top g-brd-bottom g-brd-gray-light-v4 g-py-20">
		<div class="container">
			<div class="d-sm-flex text-center">
				<div class="align-self-center">
					<h2 class="h3 g-font-weight-300 w-100 g-mb-10 g-mb-0--md">Error 404</h2>
				</div>
				<div class="align-self-center ml-auto">
					<ul class="u-list-inline">
						<li class="list-inline-item g-mr-5">
							<a class="u-link-v5 g-color-main" href="/">Inicio</a>
							<i class="g-color-gray-light-v2 g-ml-5">/</i>
						</li>
						<li class="list-inline-item g-color-primary">
							<span>Error 404</span>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</section>
</div>
<section class="container g-pt-50 g-pb-40">
	<div class="row">
		<div class="col-lg-9">
			<p>Hemos actualziado nuestra web y algunos enlaces han sido eliminados o cambiados a una nueva versión.</p>
			<p>Si deseas, aqui te dejamos algunos enlaces que pueden interesarte.</p>
		</div>
		<div class="col-lg-3">
			<?php require_once('sidebar-servicios.php'); ?>
		</div>
	</div>
</section>
<?php require_once('contact.php'); ?>